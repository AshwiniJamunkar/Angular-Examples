import { Component, OnChanges, OnInit } from '@angular/core';
import {StudentService} from '../Services/student.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
sid:number = 0;
sname:string='';
course:string='';
age:number=0;
email:any='';
errorMsg:string='';
showMsg:boolean=false;
disbaledTxt:boolean=false;
students:any[]=[];

  constructor(private studentServ : StudentService) { }

  ngOnInit(): void {
    
  }

  clearFields():void{
    this.sid=0;
    this.sname='';
    this.course='';
    this.age=0;
    this.email=''
  }

  getData():void{
  this.students  =  this.studentServ.getStudentData();
  }


  addData():void{
   if(this.sid<=0){
    this.showMsg=true;
       this.errorMsg='Please Enter valid student Id';
   }
   else{
    for(let i=0;i<this.students.length;i++){
      if(this.students[i].sid == this.sid){
       this.showMsg=true;
       this.errorMsg='Please Enter Unique student Id';
       break;
   }
   else{
    this.showMsg=false;
    this.errorMsg='';
   }
 }
}
   if(this.showMsg==false){
    let stud:any={};
    stud.sid = this.sid;
    stud.sname = this.sname;
    stud.course = this.course;
    stud.age = this.age;
    stud.email = this.email;
    //this.students.push(stud);
    this.studentServ.addStudentData(stud);
    this.showMsg=false;
    this.errorMsg='';
    this.clearFields();
    this.getData();
   }
 
}
  selectId(sid:number):void{
    
    let stud = this.studentServ.selectStudentData(sid);
    this.sid = stud.sid;
    this.sname = stud.sname;
    this.course = stud.course;
    this.age = stud.age;
    this.email = stud.email;
    this.disbaledTxt =true;
    this.showMsg=false;
    this.errorMsg='';
  }

  
  updateData():void{
    let stud:any={};
    stud.sid = this.sid;
    stud.sname = this.sname;
    stud.course = this.course;
    stud.age = this.age;
    stud.email = this.email;

    this.studentServ.updateStudentData(stud);
    
    this.disbaledTxt =false;
    this.clearFields();
    this.showMsg=false;
    this.errorMsg='';
  }


  removeId(sid:number):void{
    this.studentServ.removestudentData(sid);
    this.showMsg=false;
    this.errorMsg='';
  }
}
