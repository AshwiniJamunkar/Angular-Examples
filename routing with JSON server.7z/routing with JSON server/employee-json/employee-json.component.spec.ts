import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeJsonComponent } from './employee-json.component';

describe('EmployeeJsonComponent', () => {
  let component: EmployeeJsonComponent;
  let fixture: ComponentFixture<EmployeeJsonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeeJsonComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeJsonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
