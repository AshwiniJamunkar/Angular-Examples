import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-employee-json',
  templateUrl: './employee-json.component.html',
  styleUrls: ['./employee-json.component.css']
})
export class EmployeeJsonComponent implements OnInit {

  empId: number  = 0;
  name  :string  = "";
  designation  :string  = "";
  isDisabled :boolean = false;
  salary:number = 0;
  url:string  = "http://localhost:3000/employee";
 
   public employeeData:any[] = [];
 
 
   constructor(private dataService:DataService) { }
 
   ngOnInit(): void {
   }
 
 
   getEmpData()
   {
     
     this.dataService.getData().subscribe( (response:any[]) =>{
      this.employeeData = response;
   });
   }
 
 
   addEmpData()
   {
     let empObj:Emp = new Emp();
     empObj.empId = this.empId;
     empObj.name = this.name;
     empObj.designation = this.designation;
     empObj.salary = this.salary;
 
 
     this.dataService.addData(empObj).subscribe( (response:any) =>{
      alert("Record Added Successfully!!");
       this.clearFields();
       this.getEmpData();  
     });
   }
 
   removeEmp(empId:number)
   {
    this.dataService.deleteData(empId).subscribe( (response:any) =>{
      this.getEmpData();  
    });
   }
 
 
   selectEmp(empId:number)
   {
    
     this.dataService.getDataById(empId).subscribe( (response:any) =>{
      let empObj = response;
      this.empId =   empObj.id;
      this.name =   empObj.name;
      this.designation =  empObj.designation;
      this.salary 		=  empObj.salary;
      this.isDisabled = true;
    });

 
   }
 
   updateEmpData()
   {
     let empObj:Emp = new Emp();
     empObj.empId = this.empId;
     empObj.name = this.name;
     empObj.designation = this.designation;
     empObj.salary = this.salary;
 
 
     this.dataService.updateData(empObj).subscribe( (response:any) =>{
    
      alert("Record Updated Successfully!!");
      this.clearFields();
      this.getEmpData();
     });
 
   }
 
   clearFields()
   {
       this.isDisabled = false;
       this.empId = 0;
       this.name  = "";
       this.designation  = "";
       this.salary  = 0;
   }
 
 
 
 }
 
 
 class Emp
 {
   empId  : number = 0;
   name  : string  = "";
   designation  : string  = "";
   salary  : number  = 0;
 }
 
