import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import{FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap'; //$ npm install --save @ng-bootstrap/ng-bootstrap
import {ChartModule} from 'primeng/chart';
import { ProductsComponent } from './products/products.component';
import { StudentComponent } from './student/student.component'
import { AdminModule } from './admin/admin.module';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { ProductChildComponent } from './product-child/product-child.component';
import { ProductChildSiblingComponent } from './product-child-sibling/product-child-sibling.component';
import { HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { UserDetailsComponent } from './user-details/user-details.component';
import { GradePipePipe } from './grade-pipe.pipe';
import { StarPipePipe } from './star-pipe.pipe';
import { StudentDetailsComponent } from './student-details/student-details.component';
import { RangePipe } from './range.pipe';
import { CustomeDirectiveComponent } from './custome-directive/custome-directive.component';
import { ShadowDirective } from './shadow.directive';
import { AdminRightsDirective } from './admin-rights.directive';
import { ObservableDemoComponent } from './observable-demo/observable-demo.component';
import { EmployeeJsonComponent } from './employee-json/employee-json.component';
import {EmpDetailsComponent} from './emp-details/emp-details.component';
import {CustomHttpInterceptorService} from './custom-http-interceptor.service';
import { TemplateDrivenFormComponent } from './template-driven-form/template-driven-form.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { HomeComponent } from './routingExample/home/home.component';
import { LoginComponent } from './routingExample/login/login.component';
import { ProductDetailsComponent } from './routingExample/product-details/product-details.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductsComponent,
    StudentComponent,
    EmployeeComponent,
    EmployeeDetailsComponent,
    ProductChildComponent,
    ProductChildSiblingComponent,
    UserDetailsComponent,
    GradePipePipe,
    StarPipePipe,
    StudentDetailsComponent,
    RangePipe,
    CustomeDirectiveComponent,
    ShadowDirective,
    AdminRightsDirective,
    ObservableDemoComponent,
    EmployeeJsonComponent,
    EmpDetailsComponent,
    TemplateDrivenFormComponent,
    ReactiveFormComponent,
    HomeComponent,
    LoginComponent,
    ProductDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    ChartModule,
    FormsModule,
    AdminModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [
    { provide :  HTTP_INTERCEPTORS, useClass: CustomHttpInterceptorService, multi:true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
