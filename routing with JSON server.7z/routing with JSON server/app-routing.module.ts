import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmpDetailsComponent } from './emp-details/emp-details.component';
import { EmployeeJsonComponent } from './employee-json/employee-json.component';
import { ProductsComponent } from './products/products.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { HomeComponent } from './routingExample/home/home.component';
import { LoginComponent } from './routingExample/login/login.component';
import { ProductDetailsComponent } from './routingExample/product-details/product-details.component';
import { TemplateDrivenFormComponent } from './template-driven-form/template-driven-form.component';

const routes: Routes = [
{path:'home', component:HomeComponent},
{path:'products', component:ProductsComponent},
{path:'login', component:LoginComponent},
{path:'prodDetails/:prodId', component:ProductDetailsComponent},
{path:'empData', component:EmployeeJsonComponent},
{path:'empDetails/:empId', component:EmpDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 


}
