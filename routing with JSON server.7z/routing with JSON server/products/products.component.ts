import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  prodId:number=0;
  prodName:string='';
  prodPrice:number=0;
  prodCat:string=''
  prodQty:number=0;

  prodFormData:any = {}

products:any = [
    {id: 1, prodName: 'Mouse',prodPrice:'200',prodCat:'Hardware',prodQty:'300'},
    {id: 2, prodName: 'Keyboard',prodPrice:'400',prodCat:'Hardware',prodQty:'400'},
    {id: 3, prodName: 'mobile',prodPrice:'600',prodCat:'Hardware',prodQty:'500'},
    {id: 4, prodName: 'Touchpad',prodPrice:'800',prodCat:'Hardware',prodQty:'600'},
    {id: 5, prodName: 'Mouse',prodPrice:'900',prodCat:'Hardware',prodQty:'300'}
];

imgPath:any='assets/profile.png'

  constructor() { }

  ngOnInit(): void {
  }


  addProd(data:any):void {
    this.prodFormData.id = this.products.length+1;
    this.prodFormData.prodName = this.prodName;
    this.prodFormData.prodPrice = this.prodPrice;
    this.prodFormData.prodCat = this.prodCat;
    this.prodFormData.prodQty = this.prodQty;
  this.products.push(this.prodFormData);
  }
}