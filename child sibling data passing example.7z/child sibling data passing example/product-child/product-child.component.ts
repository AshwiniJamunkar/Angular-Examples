import { Component, OnInit,EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-product-child',
  templateUrl: './product-child.component.html',
  styleUrls: ['./product-child.component.css']
})
export class ProductChildComponent implements OnInit {

  productDropdownTitle:string = 'Product Name'
  prodSort:string='Product Names'
  constructor() { }


  @Output()
  prodChangeFromChild :EventEmitter<string> = new EventEmitter();
  @Output()
  prodChangeFromChild_sort :EventEmitter<string> = new EventEmitter();


  ngOnInit(): void {
  }

  getProductData():void{
    this.prodChangeFromChild.emit(this.productDropdownTitle);

  }
  getProductSortData():void{
    this.prodChangeFromChild_sort.emit(this.prodSort);

  }
}
