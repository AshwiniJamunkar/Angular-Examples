import { Component, Input, OnChanges, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-child-sibling',
  templateUrl: './product-child-sibling.component.html',
  styleUrls: ['./product-child-sibling.component.css']
})
export class ProductChildSiblingComponent implements OnChanges {

  @Input() prodNamefromParent:string='';
  @Input() prodChangeFromChildsort: string='';

  
  public tempProdData:any[] = [];

  public prodData:any[] = [
    {"prodName":'ITB Samsung HDD',"unitPrice":"2000","inStock":"200"},
    {"prodName":'Printer',"unitPrice":"3000","inStock":"300"},
    {"prodName":'4GBRAM',"unitPrice":"4000","inStock":"200"},
    {"prodName":'32GBUSB',"unitPrice":"5000","inStock":"400"},
    ];
 
    constructor()
    {
        this.tempProdData = this.prodData;
    }

    
  //  sortBy(a:any,p:any):void{
  //     return a.sort(function(a,b){
  //                     var sp = p.find(k => a[k] - b[k]); // find the property to compare;
  //                     return a[sp] - b[sp];
  //                   });
  //   }
    
    ngOnChanges(): void
    {
      // var data = this.prodChangeFromChildsort
      
      // this.tempProdData.sort((a,b) => a.data.rendered.localeCompare(b.titdatale.rendered));


      if(this.prodChangeFromChildsort=='Product Names'){

        this.tempProdData.sort(function(a,b) {
          return (a.prodName > b.prodName) ? 1 : ((b.prodName > a.prodName) ? -1 : 0);
        } );
        return;
      }

      if(this.prodChangeFromChildsort=='Price'){ 
        this.tempProdData.sort(function(a,b) {
          return (a.unitPrice > b.unitPrice) ? 1 : ((b.unitPrice > a.unitPrice) ? -1 : 0);}
           );
        return;

      }
      
      if(this.prodChangeFromChildsort=='Quantity'){ 
        this.tempProdData.sort(function(a,b) {
          return (a.inStock > b.inStock) ? 1 : ((b.inStock > a.inStock) ? -1 : 0);}
           );
        return;

      }
      if(this.prodNamefromParent == "Product Name")
      {
        this.tempProdData = this.prodData;
        return;
      }
      if(this.prodNamefromParent != "Product Name")
      {
        this.tempProdData = this.prodData.filter(item =>item.prodName == this.prodNamefromParent);
        return;
      }
        

    }
    


}
