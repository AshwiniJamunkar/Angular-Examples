import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductChildSiblingComponent } from './product-child-sibling.component';

describe('ProductChildSiblingComponent', () => {
  let component: ProductChildSiblingComponent;
  let fixture: ComponentFixture<ProductChildSiblingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductChildSiblingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductChildSiblingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
