import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  dataArray:any[] =  [];
  url:string  = "http://localhost:3000/employees";

  constructor(private httpObj: HttpClient) {

  }

  getData():Observable<any[]>
  {
      return this.httpObj.get<any[]>(this.url);
  }

  getDataById(id:number) : Observable<any>
  {
  
    return this.httpObj.get<any>(`${this.url}/${id}`);
  }

  addData(empObj:any) : Observable<any>
  {
    return this.httpObj.post<any>(this.url, empObj);
  }

  updateData(empObj:any) : Observable<any>
  {
    return this.httpObj.put<any>(this.url + "/" + empObj.empId, empObj);
  }

  deleteData(id:number) : Observable<any>
  {
    return this.httpObj.delete<any>(`${this.url}/${id}`);
  }
}
