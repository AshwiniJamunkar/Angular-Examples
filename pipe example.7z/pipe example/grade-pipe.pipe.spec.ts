import { GradePipePipe } from './grade-pipe.pipe';

describe('GradePipePipe', () => {
  it('create an instance', () => {
    const pipe = new GradePipePipe();
    expect(pipe).toBeTruthy();
  });
});
