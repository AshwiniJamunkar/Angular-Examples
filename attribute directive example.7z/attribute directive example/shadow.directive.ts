import { Directive,ElementRef,Input, OnChanges, OnInit } from '@angular/core';

@Directive({
  selector: '[appShadow]'
})
export class ShadowDirective implements OnInit, OnChanges{

  
  @Input() appShadow:string='';

  constructor(private element:ElementRef) {
  
 // this.element.nativeElement.style.backgroundColor = "red";

   }
  ngOnInit(){
   
    this.element.nativeElement.style.backgroundColor = "aqua";
 }
 ngOnChanges(){
  
  this.element.nativeElement.style.backgroundColor = this.appShadow;
  
 }

}
