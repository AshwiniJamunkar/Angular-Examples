import { AdminRightsDirective } from './admin-rights.directive';

describe('AdminRightsDirective', () => {
  it('should create an instance', () => {
    const directive = new AdminRightsDirective();
    expect(directive).toBeTruthy();
  });
});
