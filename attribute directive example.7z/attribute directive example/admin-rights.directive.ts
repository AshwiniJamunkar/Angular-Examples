import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appAdminRights]'
})
export class AdminRightsDirective {

  @Input()  appAdminRights: string = '';
  usersArray : string[] = [];
  display:boolean=false;

  constructor(private viewContainer: ViewContainerRef,
    private templateRef: TemplateRef<any>)
  {

  }

  ngOnInit()
  {
    this.usersArray = ['Smith','Scott','Robert'];
    
    for(var i=0;i<this.usersArray.length;i++){
      if(this.usersArray[i] == this.appAdminRights){
        this.display = true;
        this.viewContainer.createEmbeddedView(this.templateRef);
        return;
      }
      else{
        this.display=false;
        this.viewContainer.clear();
      }
    }

  }

}
