import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custome-directive',
  templateUrl: './custome-directive.component.html',
  styleUrls: ['./custome-directive.component.css']
})
export class CustomeDirectiveComponent implements OnInit {

 selectedColor:string = '';
 userName: string = '';
 login:boolean = false;
  constructor() { }

  ngOnInit(): void {
  }

  doLogin(){
    this.login =true;
    
  }

}
