import { ShadowDirective } from './shadow.directive';

describe('ShadowDirective', () => {
  it('should create an instance', () => {
    const directive = new ShadowDirective();
    expect(directive).toBeTruthy();
  });
});
