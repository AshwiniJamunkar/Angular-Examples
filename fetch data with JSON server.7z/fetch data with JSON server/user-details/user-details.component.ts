import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {

  
  usersArray:any[]=[];
  empArray:any[]=[];
  constructor(private httpReq: HttpClient) { }

  ngOnInit(): void {
  
  }

  viewMore()
  {
    
    let url:any  = "https://reqres.in/api/users";
    this.httpReq.get(url).subscribe( (response:any) => {
    this.usersArray = response.data;
  });

  
}


getEmpData()
{
  
  let url:any  = "https://dummy.restapiexample.com/api/v1/employees";
  this.httpReq.get(url).subscribe( (response:any) => {
  this.empArray = response.data;
});

  
}
}
