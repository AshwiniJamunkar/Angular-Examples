import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import{FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap'; //$ npm install --save @ng-bootstrap/ng-bootstrap
import {ChartModule} from 'primeng/chart';
import { ProductsComponent } from './products/products.component';
import { StudentComponent } from './student/student.component'
import { AdminModule } from './admin/admin.module';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { ProductChildComponent } from './product-child/product-child.component';
import { ProductChildSiblingComponent } from './product-child-sibling/product-child-sibling.component';

import { UserDetailsComponent } from './user-details/user-details.component';
import { GradePipePipe } from './grade-pipe.pipe';
import { StarPipePipe } from './star-pipe.pipe';
import { StudentDetailsComponent } from './student-details/student-details.component';
import { RangePipe } from './range.pipe';
import { CustomeDirectiveComponent } from './custome-directive/custome-directive.component';
import { ShadowDirective } from './shadow.directive';
import { AdminRightsDirective } from './admin-rights.directive';

@NgModule({
  declarations: [
    AppComponent,
    ProductsComponent,
    StudentComponent,
    EmployeeComponent,
    EmployeeDetailsComponent,
    ProductChildComponent,
    ProductChildSiblingComponent,
    UserDetailsComponent,
    GradePipePipe,
    StarPipePipe,
    StudentDetailsComponent,
    RangePipe,
    CustomeDirectiveComponent,
    ShadowDirective,
    AdminRightsDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    ChartModule,
    FormsModule,
    AdminModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
