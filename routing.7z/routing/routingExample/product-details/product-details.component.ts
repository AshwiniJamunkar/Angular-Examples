import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

prodObj:any={} 
products:any[] = [
  {id: 1, prodName: 'Mouse',prodPrice:'200',prodCat:'Hardware',prodQty:'300'},
  {id: 2, prodName: 'Keyboard',prodPrice:'400',prodCat:'Hardware',prodQty:'400'},
  {id: 3, prodName: 'mobile',prodPrice:'600',prodCat:'Hardware',prodQty:'500'},
  {id: 4, prodName: 'Touchpad',prodPrice:'800',prodCat:'Hardware',prodQty:'600'},
  {id: 5, prodName: 'Mouse',prodPrice:'900',prodCat:'Hardware',prodQty:'300'}
];

  constructor(private _activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {

    let prodId = this._activatedRoute.snapshot.params["prodId"];

    this.prodObj = this.products.find(item=>item.id == prodId); 
  }

}
